St. Clare College of Caloocan brand kit

Colours: Maroon 700 #7a0c1e (primary), Crimson 600 #a6192e, Red 500 #c8102e, Seal Gold #e0ad1c, Ebony #141211, Maroon 950/900/800 #24040a/#3d0610/#5c0a17.
Fonts: Plus Jakarta Sans (headings), Inter (body) - free on Google Fonts.
Use the seal only as supplied. Confirm fees and dates with admissions (02) 8232-4483 before printing.
Full guide: brand-kit/index.html on the website.
